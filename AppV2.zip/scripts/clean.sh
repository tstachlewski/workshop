#!/bin/bash
sudo rm -rfv /var/www/html
